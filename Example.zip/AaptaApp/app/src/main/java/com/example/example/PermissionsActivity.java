package com.example.example;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class PermissionsActivity extends AppCompatActivity {
    BluetoothAdapter bluetoothAdapter;
    LocationManager locationManager;
    boolean GpsStatus;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);
        Button b1 = (Button) findViewById(R.id.btn1);
        final BluetoothAdapter bAdapter = BluetoothAdapter.getDefaultAdapter();
        b1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onClick(View v) {
                if (bAdapter == null) {
                    Toast.makeText(getApplicationContext(), "Bluetooth Not Supported", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (!bAdapter.isEnabled()) {
                        startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 1);
                        Toast.makeText(getApplicationContext(), "Bluetooth Turned ON", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        if (bAdapter.isEnabled()) {
                            Toast.makeText(getApplicationContext(), "Bluetooth already Turned ON", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
        Button gps = (Button) findViewById(R.id.btn2);
        context = getApplicationContext();
        CheckGpsStatus();
        gps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent i1 = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(i1);
            }
        });
        //ok button to move to next page
        Button b2 = (Button) findViewById(R.id.btnOk);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PermissionsActivity.this, DisplayActivity.class);
                startActivity(i);
                finish();
            }
        });
        //Back button
        TextView t = (TextView) findViewById(R.id.text1);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PermissionsActivity.this, OptionsActivity.class);
                startActivity(i);
                finish();
            }
        });
    }

    public void CheckGpsStatus() {
        locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        assert locationManager != null;
        GpsStatus = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

}
